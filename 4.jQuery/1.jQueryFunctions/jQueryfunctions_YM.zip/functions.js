$(document).ready(function(){

    $('#addClass button').click(function(){
        $('#addClass p').addClass('red');
    });

    $('#before button').click(function(){
        $("#before h1").before("Before The Header!");
    })
    // put your code for the remaining functions below

    $("#after button").click(function(){
        $("#after h1").after("After The Header");
    })
    
    $("#append button").click(function(){
        $("#append h1").append("Added a New One");
    })

    $('#click button').click(function(){
            alert("Hello! Looks like you selected the button!");
    });
    
    $('#click button').click(function(){
            alert("Hello! Looks like you selected the button!");
    });
    
    $("#hide button").click(function(){
            $("#hide p").hide();
    });
    
    $("#show button").click(function(){
            $("p").show();
    });
    
    $("#toggle button").click(function(){
            $("p").toggle();
    });
    
    $("#slideDown button").click(function(){
            $("p").slideDown();
    });

});